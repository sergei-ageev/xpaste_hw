$(function() {
  $('.ui.dropdown').dropdown();
});
